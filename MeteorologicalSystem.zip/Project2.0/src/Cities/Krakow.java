package Cities;

import Devices.Device3;

public class Krakow extends City {
    private String name = "Krakow";
    private Device3 d3 = new Device3();

    public Krakow(){
        setDevice(d3);
    }


    @Override
    public void info() {
        setName(name);
        super.info();
    }
}
