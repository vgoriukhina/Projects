package Cities;

import Devices.Device;
import Devices.Device2;
import Devices.Device3;

import java.util.ArrayList;

public class Warsaw extends City {
    private String name = "Warsaw";
    private Device2 d2 = new Device2();

    public Warsaw(){
        setDevice(d2);
    }


    @Override
    public void info() {
        setName(name);
        super.info();
    }
}
