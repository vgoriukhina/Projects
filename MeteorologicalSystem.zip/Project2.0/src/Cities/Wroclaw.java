package Cities;

import Devices.Device;
import Devices.Device1;
import Devices.Device3;

import java.util.ArrayList;

public class Wroclaw extends City{
    private ArrayList<Device> stuffWr = new ArrayList<>();
    private String name="Wroclaw";
    private Device1 d1 =new Device1();

    public Wroclaw(){
        setDevice(d1);
    }

    @Override
    public void info() {
        setName(name);
        super.info();
    }


}
