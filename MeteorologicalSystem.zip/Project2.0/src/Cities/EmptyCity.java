package Cities;

import java.util.ArrayList;

public class EmptyCity extends City{
    private String name;

    public EmptyCity(String name) {
        this.name = name;
        setName(name);
    }


    @Override
    public void info() {
        super.info();
    }

    @Override
    public String getName() {
        return name;
    }
}
