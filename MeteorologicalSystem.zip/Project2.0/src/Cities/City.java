package Cities;

import Devices.Device;
import Devices.MeasuringStuff.Measureable;
import com.company.SimpleDimple;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;


public class City{
    private double humidity,temperature, wind_speed,sumHumidity=0,sumTemperature=0,sumWind=0;
    private int counter=0;
    private Device device;
    private String name;
    private ArrayList<Double> values = new ArrayList<>();
    private ArrayList<String> names = new ArrayList<>();

    public void info(){
        System.out.println(name);
        device.info();
    }

    public void measuring(){
            device.work();
    }

    public SimpleDimple getlastMeasure(){
        counter++;
        Gson gson= new Gson();

        System.out.println(getName());
        for (Measureable m: device.getStuff()){
            values.add(m.lastMeasure());
            names.add(m.getName());
        }
        SimpleDimple s = new SimpleDimple(name);
        s.readMeasure(names,values.get(0),values.get(1),values.get(2), values.get(3));

        return s ;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

}
