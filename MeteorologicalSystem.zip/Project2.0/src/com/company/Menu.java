package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
    private ArrayList<String> uc = new ArrayList<>();
    private String in;
    private CSI csi;
    public Menu(){
        csi = new CSI();
    }
    public String scan(){
        Scanner sc = new Scanner(System.in);
        in = sc.nextLine();
        return in;
    }
    public void start() throws InterruptedException {
        do {
            System.out.println("1.Zaloguj się  2.Koniec programu");
            scan();
            switch (in) {
                case "1":
                    startKupa();
                    break;
                case "2":
                    System.out.println("Dziękujęmy, że jesteś z nami.");
                default:
                    System.out.println("Wystąpił bład. Uruchom ponownie.");
            }
        }
        while (!in.equals("2"));
    }

    public void startKupa() throws InterruptedException {
        System.out.println("Podaj nazwę użytkownika:");
        String name = scan();
        KUPA kupa = new KUPA(csi,uc,name);
        do {
            System.out.println("1subskrybuj miasto 2.anuluj subskrybcję 3.Pokaż statystykę miasta 0.koniec");
            scan();
            switch (in) {
                case "1":
                    chooseCity(csi);
                    kupa.register(csi, in);
                    break;
                case "0":
                    kupa.theEnd(csi);
                    break;
                case "2":
                    System.out.println("Wybierż miasto, które nie chcesz subskrybować\n"+kupa.getU().getSubs());
                    scan();
                    kupa.removeRegister(csi,in);
                    break;
                case "3":
                    System.out.println(kupa.getU().getT());
                    break;
            }
        }
        while (!in.equalsIgnoreCase("0"));

    }
    public void chooseCity(CSI csi){
        System.out.println("Lista lokalizacji");
        csi.showListOfCities();
        System.out.println("Wybierz lokalizację lub wybierz 0, aby contynuować");//в петлю
        scan();
        if (!in.equalsIgnoreCase("0")) {
            System.out.println("Subskrybujesz " + in);
        }
    }
}
