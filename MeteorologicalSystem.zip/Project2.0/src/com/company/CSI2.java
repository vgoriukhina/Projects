//package com.company;
//
//import Cities.City;
//
//import java.util.ArrayList;
//
//    public class CSI2 {
//        private ArrayList<User> users = new ArrayList<>();
//        private ArrayList<City> city = new ArrayList<City>();
//        private Thread t;
//        private boolean condition;
//        private Object synchronization = new Object();
//
//        public CSI() {
//            t = new Thread(()->run());
//        }
//
//        public void addUser(User u, ArrayList<String> cities){
//            synchronized (synchronization) {
//                users.add(u);
//            }
//        }
//        public void addLocalization(){
//
//        }
//        public void update(){
//            synchronized (synchronization){
//                for (User u: users) {
//                    u.sendInfo();
//                }
//            }
//        }
//        public void run(){
//            while (condition==true) {
//
//                update();
//                try {
//                    t.sleep(1500);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//        public void startProgram(){
//            condition=true;
//            t.start();
//        }
//        public void stopProgram()  {
//            condition=false;
//        }
//        public void stopFinish(){
//            try {
//                t.join();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//
//        public ArrayList<City> getCity() {
//            return city;
//        }
//    }
//
//}
