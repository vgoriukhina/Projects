package com.company;

import com.google.gson.Gson;

import java.util.ArrayList;

public class SimpleDimple {
    private String name;
    private Double temp=100.0,windS=100.0,preasure=100.0,hum=100.0,sumHumidity=0.0,sumTemperature=0.0,sumWind=0.0,sumPr=0.0;
    private int counter=0;
    private ArrayList<String> names= new ArrayList<>();
    private ArrayList<Double> v1 = new ArrayList<>();
    private ArrayList<Double> v2 = new ArrayList<>();
    private ArrayList<Double> v3 = new ArrayList<>();
    private ArrayList<Double> v4 = new ArrayList<>();

    public SimpleDimple(String name) {
        this.name = name;

    }
    public void readMeasure(ArrayList<String> names,Double windS,Double preasure,Double hum,Double temp){
        this.names=names;
        counter++;
        sumWind+=windS;
        sumPr+=preasure;
        sumHumidity+=hum;
        sumTemperature+=temp;
        v1.add(windS);
        v2.add(preasure);
        v3.add(hum);
        v4.add(temp);
    }
    public Gson statistics() {
        Double avHum = sumHumidity / counter;
        Double avTemp = sumTemperature / counter;
        Double avWS = sumWind / counter;
        Double avPr = sumPr/counter;
        String av = String.format("average:%15.3f%15.3f%15.3f%15.3f\n",avWS,avPr, avHum, avTemp);
        String max = String.format("max:%15.3f%15.3f%15.3f%15.3f\n",max(v1),max(v2),max(v3),max(v4) );
        String min = String.format("min:%15.3f%15.3f%15.3f%15.3f\n",min(v1),min(v2),min(v3),min(v4) );
        Gson gson = new Gson();
        gson.toJson(names);
        gson.toJson(v1);
        gson.toJson(v2);
        gson.toJson(v3);
        gson.toJson(v4);
        gson.toJson(av);
        gson.toJson(max);
        gson.toJson(min);
        return gson;
    }

    public Double max(ArrayList<Double> v){
        Double max =-10000.0;
        for (Double value : v){
            if (max<value){
                max=value;
            }
        }
        return max;
    }
    public Double min(ArrayList<Double> v){
        Double min =10000.0;
        for (Double value : v){
            if (min>value){
                min=value;
            }
        }
        return min;
    }

    public static void main(String[] args) {
        SimpleDimple s = new SimpleDimple("loh");
        ArrayList<Double> d = new ArrayList<>();
        d.add(3.4);
        d.add(2.0);
        d.add(7.0);
        System.out.println(s.max(d));
        System.out.println(s.min(d));
    }

}
