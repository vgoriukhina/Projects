package com.company;

import com.google.gson.Gson;

import java.util.ArrayList;

public class User {
    private ArrayList<String> subs = new ArrayList<>();
    private ArrayList<String> t = new ArrayList<>();
    private String name;
    private Double average=0.0,max=0.0,min=0.0;

    public User(String name) {
        this.name = name;
    }

    public void sendInfo(SimpleDimple s, String cityName){
        System.out.println(cityName+" informacja jest zapisana");

    }


    public void subscribe(String city){
        subs.add(city);
    }
    public void removeSub(String city){
        subs.remove(city);
    }

    public ArrayList<String> getSubs() {
        return subs;
    }

    public void setSubs(ArrayList<String> subs) {
        this.subs = subs;
    }

    public String getName() {
        return name;
    }

    public ArrayList<String> getT() {
        return t;
    }
}
