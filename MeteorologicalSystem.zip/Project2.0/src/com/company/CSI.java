package com.company;

import Cities.*;

import java.util.ArrayList;

public class CSI {

    private Thread t;
    private boolean condition;
    private ArrayList<User> users = new ArrayList<>();
    private ArrayList<City> cities= new ArrayList<>();
    private Object synchronization = new Object();

    public CSI() {
        cities.add(new Wroclaw());
        cities.add(new Warsaw());
        cities.add(new Krakow());
        t = new Thread(()->run());
    }

    public void showListOfCities(){
        for(City city : cities){
            city.info();
        }
    }

    public void register(User u, String city){
        synchronized (synchronization){
            u.subscribe(city);
        }
    }
    public void removeRegister(User u, String city){
        synchronized (synchronization){
            u.removeSub(city);
        }
    }
    public void addUser(User u){  //String cityName
        synchronized (synchronization) {
            users.add(u);
        }
    }
    public void sendInfo(City city){
        synchronized (synchronization){
            for (User u: users) {
                for (String sc : u.getSubs()) {
                    if (city.getName().equalsIgnoreCase(sc)) {
                        System.out.println(u.getName());
                        u.sendInfo(city.getlastMeasure(), city.getName());
                    }
                }
            }
        }
    }

    public void run(){
        while (condition==true) {

            for (City city :cities){
                city.measuring();
                sendInfo(city);
            }

            try {
                t.sleep(5000);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public void startProgram(){
        condition=true;
        t.start();
    }
    public void stopProgram()  {
        condition=false;
    }
    public void stopFinish(){
        try {
            t.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<City> getCities() {
        return cities;
    }
}
