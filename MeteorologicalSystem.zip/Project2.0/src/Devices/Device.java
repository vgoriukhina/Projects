package Devices;

import Devices.MeasuringStuff.Measureable;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Collections;

public abstract class Device {
    private String name;
    private Double temp=100.0,windS=100.0,preasure=100.0,hum=100.0;
    private ArrayList<String> nameOfMeasurable = new ArrayList<>();


    private ArrayList<Measureable> stuff = new ArrayList<>();

    public void work(){
        for (Measureable measureable : stuff) {
            measureable.measure();
        }
    }
    public void info(){
        for (Measureable m : stuff){
            nameOfMeasurable.add(m.getName());
            System.out.print(m.getName()+"/");
        }
        System.out.println();
    }


    public void setStuff(ArrayList<Measureable> stuff) {
        Collections.sort(stuff);
        this.stuff = stuff;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Measureable> getStuff() {
        return stuff;
    }

    public void setTemp(Double temp) {
        this.temp = temp;
    }

    public void setWindS(Double windS) {
        this.windS = windS;
    }

    public void setPreasure(Double preasure) {
        this.preasure = preasure;
    }

    public void setHum(Double hum) {
        this.hum = hum;
    }

    public String getName() {
        return name;
    }

    public ArrayList<String> getNameOfMeasurable() {
        return nameOfMeasurable;
    }
}
