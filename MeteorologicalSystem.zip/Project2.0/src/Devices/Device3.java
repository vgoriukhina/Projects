package Devices;

import Devices.MeasuringStuff.*;

import java.util.ArrayList;

public class Device3 extends Device {
    private String name = "d3";
    private Barometer barometer = new Barometer();
    private Thermometer thermometer=new Thermometer();
    private Hygrometer hygrometer = new Hygrometer();
    private ArrayList<Measureable> stuff = new ArrayList();

    public Device3() {
        setName(name);
        stuff.add(new Epmty("wind speed not found"));
        stuff.add(barometer);
        stuff.add(hygrometer);
        stuff.add(thermometer);
        setStuff(stuff);

        setHum(barometer.getM());
        setTemp(thermometer.getM());

    }
}
