package Devices;

import Devices.MeasuringStuff.*;

import java.util.ArrayList;

public class Device2 extends Device {

    private String name = "d2";
    private Anemometer anemometer = new Anemometer();
    private Thermometer thermometer= new Thermometer();
    private Barometer barometer = new Barometer();
    private ArrayList<Measureable> stuff = new ArrayList();

    public Device2()  {
        setName(name);
        stuff.add(anemometer);
        stuff.add(barometer);
        stuff.add(new Epmty("humidity not found"));
        stuff.add(thermometer);

        setStuff(stuff);

        setHum(anemometer.getM());
        setTemp(thermometer.getM());
    }
}
