package Devices.MeasuringStuff;

import javax.xml.namespace.QName;
import java.util.Random;

public class Hygrometer extends Measureable {
    private Double humidity=0.0,sumHum=0.0,avHum=0.0;
    private int counter=2;
    private String name = "humidity",endOfName="g/m^3";

    public Hygrometer(){
        setName(name);
        setEndOfName(endOfName);
    }
    @Override
    public void sum() {
        sumHum+=humidity;
    }

    @Override
    public void average() {
        avHum=sumHum/counter;
    }

    @Override
    public void measure() {
        Random r = new Random();
        humidity = r.nextDouble(0, 100);
        setM(humidity);
    }

    @Override
    public String getName() {
        return super.getName();
    }
}
