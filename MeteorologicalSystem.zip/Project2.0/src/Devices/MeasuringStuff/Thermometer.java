package Devices.MeasuringStuff;

import java.util.Random;

public class Thermometer extends Measureable {
    private Double temperature=0.0,sumTemp=0.0,avTemp=0.0;
    private int counter=3;
    private String name = "temperature",endOfName="C";

    public Thermometer() {
        setName(name);
        setEndOfName(endOfName);
    }

    @Override
    public void sum() {
        sumTemp+=temperature;
    }

    @Override
    public void average() {
        avTemp=sumTemp/counter;
    }

    @Override
    public void measure() {
        Random r = new Random();
        temperature=r.nextDouble(-40,60);
        setM(temperature);
    }


    @Override
    public String getName() {
        return super.getName();
    }
}
