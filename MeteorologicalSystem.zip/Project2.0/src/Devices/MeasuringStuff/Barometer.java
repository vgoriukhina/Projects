package Devices.MeasuringStuff;

import java.util.Random;

public class Barometer extends Measureable{
    private Double preasure=0.0,sumPr=0.0,avPr=0.0;
    private int counter=1;
    private String name = "preasure",endOfName="mmHg";

    public Barometer() {
        setName(name);
        setEndOfName(endOfName);
    }

    @Override
    public void sum() {
        sumPr+=preasure;
    }

    @Override
    public void average() {
        avPr=sumPr/counter;
    }

    @Override
    public void measure() {
        counter++;
        Random r = new Random();
        preasure = r.nextDouble(740, 780);
        setM(preasure);
    }

    @Override
    public String getName() {
        return super.getName();
    }
}
