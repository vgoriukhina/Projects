package Devices.MeasuringStuff;

import java.util.Random;

public class Epmty extends Measureable{
    private String name;
//    private ArrayList<Double> values = new ArrayList<>();

    public Epmty(String name){
        this.name=name+" Eror404";
        setName(name);

    }
    @Override
    public void measure() {
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
