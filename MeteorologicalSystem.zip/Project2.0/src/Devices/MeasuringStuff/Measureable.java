package Devices.MeasuringStuff;

import com.google.gson.Gson;

import java.util.ArrayList;

public abstract class Measureable implements Runnable,Comparable{
    private boolean condition=true;
    private String name="",endOfName="";
    private Double m=0.0;

    public void measure() {
    }

    public Double lastMeasure(){
        System.out.printf("%-15s%6.2f%6s \n",getName(),m,endOfName);
        return m;
    }

    @Override
    public void run() {
        while (condition==true){
            measure();
        }
    }

    public int compareTo(Measureable o) {
        return getName().compareTo(o.getName());
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Double getM() {
        return m;
    }

    public void setM(Double m) {
        this.m = m;
    }


    public void setEndOfName(String endOfName) {
        this.endOfName = endOfName;
    }
}
