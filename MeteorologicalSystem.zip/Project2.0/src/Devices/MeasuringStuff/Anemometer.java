package Devices.MeasuringStuff;

import java.util.ArrayList;
import java.util.Random;

public class Anemometer extends Measureable {
    private Double windSpeed=0.0,sumWS=0.0,avWS=0.0;
    private int counter=0;
    private String name = "wind speed",endOfName="km/s";
//    private ArrayList<Double> values = new ArrayList<>();

    public Anemometer(){
        setName(name);
        setEndOfName(endOfName);
    }
    @Override
    public void sum() {
        sumWS+=windSpeed;
    }

    @Override
    public void average() {
        avWS=sumWS/counter;
    }

    @Override
    public void measure() {
        Random r = new Random();
        windSpeed = r.nextDouble(0, 60);
        setM(windSpeed);
    }

    @Override
    public String getName() {
        return super.getName();
    }
}
