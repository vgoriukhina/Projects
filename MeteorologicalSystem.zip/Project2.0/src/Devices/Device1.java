package Devices;


import Devices.MeasuringStuff.*;

import java.util.ArrayList;

public class Device1 extends Device {
    private String name = "d1";
    private Hygrometer hygrometer = new Hygrometer();
    private Thermometer thermometer= new Thermometer();
    private Anemometer anemometer = new Anemometer();
    private ArrayList<Measureable> stuff = new ArrayList();

    public Device1() {
        setName(name);
        stuff.add(anemometer);
        stuff.add(new Epmty("preasure not found"));
        stuff.add(hygrometer);
        stuff.add(thermometer);
        setStuff(stuff);
    }
}
